function abc() {
  return arguments[1];
}

abc(1, 2, 3); //: number
