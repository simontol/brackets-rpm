var x = new Type();

x.foo; //: string

function Type() {}
Type.prototype.foo = "hi";
