var foo = 10;

(function() {
  this.foo; //: number
})();
