define([], function() {
  return {c: "c"};
});
