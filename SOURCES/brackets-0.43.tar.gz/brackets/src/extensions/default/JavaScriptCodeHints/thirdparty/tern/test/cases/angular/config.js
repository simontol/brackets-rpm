angular.module('sample.config', [])

.value('myConfig', {
  myColor: 'red',
})

;
