// environment=span

iHaveASpan; //loc: 4, 2
