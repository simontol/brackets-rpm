define([], function() {
  return 1;
});
