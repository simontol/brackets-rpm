var x = {my: "object"};
var y = Object.create(x);
y.bar = "extended";
