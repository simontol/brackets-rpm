// "freelist" could be any other undocumented node.js API module that isn't
// included in the tern node plugin definitions.
require('freelist');
