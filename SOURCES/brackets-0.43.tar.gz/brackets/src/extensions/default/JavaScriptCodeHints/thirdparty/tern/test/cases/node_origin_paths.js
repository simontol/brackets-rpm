// plugin=node

require('./node_exports').b; //origin: node_exports.js
