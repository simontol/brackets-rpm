foo.z = {something: "else"};
