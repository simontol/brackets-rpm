define({aString: "hello"});
